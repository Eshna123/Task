package com.example.mymovie.ui.theme

const val RadiusContainer = 24
const val Radius = 20
const val MediumRadius = 16
const val SmallRadius = 8
const val BigRadius = 74