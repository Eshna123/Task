package com.example.mymovie.onboarding

sealed class OnBoardingEvent  {

    object SaveAppEntry : OnBoardingEvent()

}