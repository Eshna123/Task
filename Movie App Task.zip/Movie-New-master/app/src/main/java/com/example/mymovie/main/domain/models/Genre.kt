package com.example.mymovie.main.domain.models

import androidx.room.Entity

data class Genre(
    val id: Int,
    val name: String
)