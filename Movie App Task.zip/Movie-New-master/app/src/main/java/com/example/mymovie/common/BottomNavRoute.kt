package com.example.mymovie.common


object BottomNavRoute {
    const val MEDIA_HOME_SCREEN = "media_home_screen"
    const val MEDIA_SEARCH_SCREEN = "media_search_screen"
    const val MEDIA_LIST_SCREEN = "media_list_screen"
}