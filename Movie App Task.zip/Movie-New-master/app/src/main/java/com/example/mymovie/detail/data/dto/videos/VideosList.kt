package com.example.mymovie.detail.data.dto.videos

data class VideosList(
    val id: Int,
    val results: List<VideoDto>
)