package com.example.mymovie.detail.data.dto.details

data class DetailsDto(
    val runtime: Int,
    val status: String,
    val tagline: String,
)