package com.example.mymovie.detail.domain.models

data class Details(
    val runtime: Int?,
    val status: String?,
    val tagline: String?,
)